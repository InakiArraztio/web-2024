"use strict"

/*****************MENU DESPLEGABLE*****************/ 


document.getElementById("menu-mobile").addEventListener("click", toggleBtn);

function toggleBtn() {
    console.log("estoy adentro de la funcion");
    document.querySelector(".botonera").classList.toggle("show");
}



/*****************CAPTCHA PARA contacto.html*****************/
/*En este script, después de generar el captcha al cargar la página, se agrega un evento de clic al botón con ID captchaButton para llamar a la función verificarCaptcha cuando se haga clic en él. Esto elimina la necesidad de usar onclick en el HTML. */

// Función para generar un número aleatorio de 4 dígitos
function generarCaptcha() {
    let captcha = '';
    for (let i = 0; i < 4; i++) {
        captcha += Math.floor(Math.random() * 10);
    }
    document.getElementById('valorCaptcha').innerText = captcha;
}

// Función para verificar el captcha ingresado
function verificarCaptcha(e) {
    e.preventDefault();
    const valorCaptcha = document.getElementById('valorCaptcha').innerText;
    const inputCaptcha = document.getElementById('captchaTexto').value;
    if (valorCaptcha === inputCaptcha) {
        alert('Captcha verificado correctamente');
    } else {
        alert('Captcha incorrecto, intente de nuevo');
    }
}


/*****************VERIFICAR SI LOS CAMPOS DEL FORM ESTAN COMPLETOS*****************/
let formulario = document.getElementById("formularioCaptcha");
formulario.addEventListener('submit', verificarForm);

function verificarForm(e){
    e.preventDefault();
    //para agarrar todos los datos del form
    let form = new FormData(formulario);
    //objeto FormData
    let nombre = form.get('nombre');
    let appelido = form.get('appelido');
    let mail = form.get('mail');
    let telefono = form.get('telefono');
    console.log(nombre,appelido,mail,telefono);
    console.log("estoy en la funcion");
    
}


// Generar el captcha cuando se carga la página
window.onload = function() {
    generarCaptcha();
    
    // Agregar evento de clic al botón de verificar captcha
    document.getElementById('captchaButton').addEventListener('click', verificarCaptcha);
};