"use strict";

let tabla = document.querySelector('#tabla');
let usuarios = [];
let editado = false;
let editIndex = -1;

document.addEventListener('DOMContentLoaded', () => {
    cargarDatosIniciales();
    document.querySelector('#btnAgregar').addEventListener('click', agregarOEditarUsuario);
    document.querySelector('#btnLimpiar').addEventListener('click', limpiarTabla);
    document.querySelector('#filtroBusqueda').addEventListener('input', filtrarUsuarios);

    //Event listener para botones de editar y borrar
    tabla.addEventListener('click', (e) => {
        if (e.target.classList.contains('btn-editar')) {
            editarUsuario(e.target.closest('tr').getAttribute('data-id'));
        }
        if (e.target.classList.contains('btn-borrar')) {
            borrarUsuario(e.target.closest('tr').getAttribute('data-id'));
        }
    });
});

async function cargarDatosIniciales() {
    try {
        let response = await fetch('https://66744bc875872d0e0a95eb94.mockapi.io/wines/usuarios');
        if (!response.ok) {
            throw new Error('Error al cargar los datos');
        }
        let data = await response.json();
        usuarios = data;
        mostrar();
    } catch (error) {
        console.error('Error:', error);
    }
}

async function agregarOEditarUsuario(e) {
    e.preventDefault();
    let nombreCompleto = document.querySelector('#nombreCompleto').value;
    let email = document.querySelector('#email').value;
    let usuario = {
        nombreCompleto: nombreCompleto,
        email: email
    };
    if (!editado) {
        try {
            let response = await fetch('https://66744bc875872d0e0a95eb94.mockapi.io/wines/usuarios', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(usuario),
            });
            if (!response.ok) {
                throw new Error('Error al agregar el usuario');
            }
            let data = await response.json();
            usuarios.push(data);
            mostrar();
        } catch (error) {
            console.error('Error:', error);
        }
    } else {
        try {
            let response = await fetch(`https://66744bc875872d0e0a95eb94.mockapi.io/wines/usuarios/${usuarios[editIndex].id}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(usuario),
            });
            if (!response.ok) {
                throw new Error('Error al editar el usuario');
            }
            let data = await response.json();
            usuarios[editIndex] = data;
            editado = false;
            editIndex = -1;
            mostrar();
        } catch (error) {
            console.error('Error:', error);
        }
    }
    limpiarInputs();
}

function mostrar() {
    let filtro = document.querySelector('#filtroBusqueda').value.toLowerCase();
    tabla.innerHTML = "";
    for (let i = 0; i < usuarios.length; i++) {
        let usuario = usuarios[i];
        if (usuario && usuario.nombreCompleto && usuario.email) {
            let nombreCompleto = usuario.nombreCompleto.toLowerCase();
            let email = usuario.email.toLowerCase();
            if (nombreCompleto.includes(filtro) || email.includes(filtro)) {
                tabla.innerHTML += `
                    <tr data-id="${usuario.id}">
                        <td>${usuario.nombreCompleto}</td>
                        <td>${usuario.email}</td>
                        <td>
                            <button type="button" class="btn-editar">Editar</button>
                            <button type="button" class="btn-borrar">Borrar</button>
                        </td>
                    </tr>`;
            }
        }
    }
}

function limpiarTabla() {
    usuarios = [];
    mostrar();
}

function limpiarInputs() {
    document.querySelector('#nombreCompleto').value = '';
    document.querySelector('#email').value = '';
}

function filtrarUsuarios() {
    mostrar();
}

async function editarUsuario(id) {
    try {
        // Buscar el índice del usuario a editar
        editIndex = usuarios.findIndex(usuario => usuario.id === id);
        if (editIndex === -1) {
            throw new Error('Usuario no encontrado para editar.');
        }
        // Llenar los campos del formulario con los datos del usuario a editar
        const usuario = usuarios[editIndex];
        document.querySelector('#nombreCompleto').value = usuario.nombreCompleto;
        document.querySelector('#email').value = usuario.email;

        // Cambiar el estado para indicar que se está editando
        editado = true;
    } catch (error) {
        console.error('Error:', error);
    }
}

async function borrarUsuario(id) {
    try {//envio solicitud al servidor
        let response = await fetch(`https://66744bc875872d0e0a95eb94.mockapi.io/wines/usuarios/${id}`, {
            method: 'DELETE',
        });
        if (!response.ok) {
            throw new Error('Error al borrar el usuario');
        }

        // Filtro el usuario eliminado del array usuarios
        usuarios = usuarios.filter(usuario => usuario.id !== id);
        mostrar();
    } catch (error) {
        console.error('Error:', error);
    }
}




